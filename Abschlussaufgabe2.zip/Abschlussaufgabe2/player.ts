interface AssocStringString {
    [key: string]: string;
}


interface Symbole {
    type: string;
    x: string;
    y: string;
}

interface CanvasElement {
    type: string;
    x: string;
    y: string;
    backgroundC: string;
    size: string;
}